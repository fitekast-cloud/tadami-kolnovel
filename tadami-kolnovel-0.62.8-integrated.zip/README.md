# Tadami 0.62.8 — KolNovel / ملوك الروايات

هذا المشروع يبني إضافة Kotlin لمصدر KolNovel على Tadami.

## لماذا توجد عملية clone أثناء البناء؟
مستودع Tadami الرسمي للإضافات هو `tadamiorg/tadami-extensions-source`. بنية المستودع الحالية تعتمد على مجلدات `extensions/<lang>/<name>`، و`settings.gradle.kts` يحمّل هذه الوحدات تلقائيًا. لذلك هذا المشروع يعمل كـ overlay صغير: GitHub Actions يجلب المستودع، يضع وحدة `ar/kolnovel` داخله، ثم يشغّل Gradle.

## البناء
1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع محتويات هذا المجلد.
3. افتح Actions.
4. شغّل `Build Tadami KolNovel extension`.
5. نزّل APK من Artifacts.

> هذه الحزمة ليست APK جاهزًا ولا تدّعي نجاح البناء على خوادم GitHub قبل تشغيل Action فعليًا.

ملاحظات Tadami 0.62.8:
- Tadami 0.61 وما بعده يستخدم نظام Extension Stores الجديد ويدعم `index.pb` / `jarUrl`.
- المستودع الرسمي للإضافات يضع الوحدات تحت `extensions/<lang>/<name>`.
