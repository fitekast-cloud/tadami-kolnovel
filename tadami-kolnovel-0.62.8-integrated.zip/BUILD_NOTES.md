# Verification notes

- Tadami v0.62.8 release notes confirm the modern extension-store/index behavior and novel extension API work.
- The Tadami extension source repository's `settings.gradle.kts` loads `extensions/<lang>/<name>` modules.
- `common.gradle` sets the Android namespace to `com.sf.tadami.extension.<pkgNameSuffix>` and uses Java/Kotlin 17.
- This package therefore targets `extensions/ar/kolnovel` with package metadata `com.sf.tadami.extension.ar.kolnovel`.
