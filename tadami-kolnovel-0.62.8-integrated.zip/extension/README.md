KolNovel Tadami extension overlay. The build workflow copies the module into tadamiorg/tadami-extensions-source before compiling.
