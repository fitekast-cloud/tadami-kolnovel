package eu.kanade.tachiyomi.extension.ar.kolnovel

import eu.kanade.tachiyomi.novelsource.model.NovelFilterList
import eu.kanade.tachiyomi.novelsource.model.SNovel
import eu.kanade.tachiyomi.novelsource.model.SNovelChapter
import eu.kanade.tachiyomi.novelsource.online.ParsedNovelHttpSource
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class KolNovel : ParsedNovelHttpSource() {

    override val name = "ملوك الروايات"
    override val lang = "ar"
    override val baseUrl = "https://free.kolnovel.com"

    private val mirrors = listOf(
        "https://free.kolnovel.com",
        "https://kolnovel.com",
        "https://www.kolnovel.com",
    )

    override fun popularNovelsRequest(page: Int) =
        GET("$baseUrl/novels?page=$page")

    override fun latestNovelsRequest(page: Int) =
        GET("$baseUrl/novels?sort=updated&page=$page")

    override fun searchNovelsRequest(page: Int, query: String, filters: NovelFilterList) =
        GET("$baseUrl/search?keyword=${URLEncoder.encode(query, StandardCharsets.UTF_8)}&page=$page")

    override fun popularNovelsSelector() = ".novel-list .novel-item, .row .novel-item, .list-novel .novel-item"
    override fun latestNovelsSelector() = popularNovelsSelector()
    override fun searchNovelsSelector() = popularNovelsSelector()

    override fun novelFromElement(element: Element): SNovel {
        val link = element.selectFirst("a[href]") ?: return SNovel.create()
        val url = absoluteUrl(link.attr("href"))
        val title = element.selectFirst(".novel-title, .title, h3, h4")?.text()
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: link.text().trim()
        val cover = element.selectFirst("img")?.let { absoluteImageUrl(it.attr("data-src").ifBlank { it.attr("src") }) }
        return SNovel.create().apply {
            this.title = title
            this.setUrl(url)
            this.thumbnail_url = cover
        }
    }

    override fun novelParse(document: Document): SNovel {
        val title = document.selectFirst("h1, .novel-title, .book-title")?.text()?.trim().orEmpty()
        val cover = document.selectFirst(".novel-cover img, .book-cover img, .info-cover img, img[src]")?.let {
            absoluteImageUrl(it.attr("data-src").ifBlank { it.attr("src") })
        }
        val author = document.selectFirst(".author a, .author, [itemprop=author]")?.text()?.trim().orEmpty()
        val description = document.selectFirst(".description, .summary, .novel-description, [itemprop=description]")?.text()?.trim().orEmpty()
        val genres = document.select(".genres a, .genre a, .tags a").map { it.text().trim() }.filter { it.isNotBlank() }
        return SNovel.create().apply {
            this.title = title
            this.thumbnail_url = cover
            this.author = author
            this.description = description
            this.genre = genres.joinToString(", ")
        }
    }

    override fun chapterListSelector() =
        ".chapter-list a[href], .chapters a[href], ul.chapters li a[href], .list-chapter a[href]"

    override fun chapterFromElement(element: Element): SNovelChapter {
        val link = element.selectFirst("a[href]") ?: element
        return SNovelChapter.create().apply {
            name = link.text().trim().ifBlank { "فصل" }
            url = absoluteUrl(link.attr("href"))
        }
    }

    override fun chapterParse(document: Document): String {
        val selectors = listOf(
            ".chapter-content",
            ".reading-content",
            ".entry-content",
            ".chapter-body",
            "#chapter-content",
            "article"
        )
        val content = selectors.asSequence()
            .mapNotNull { document.selectFirst(it) }
            .firstOrNull()

        if (content == null) {
            return document.body().text().trim()
        }

        content.select("script, style, noscript, iframe, .ads, .advert, .ad, .share, .social").forEach { it.remove() }
        content.select("br").forEach { it.after("\\n") }

        return content.text()
            .replace(Regex("\\u00a0"), " ")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    override fun pageListParse(document: Document): List<String> = emptyList()

    override fun pageListRequest(chapter: SNovelChapter) = GET(absoluteUrl(chapter.url))

    override fun chapterRequest(chapter: SNovelChapter) = GET(absoluteUrl(chapter.url))

    override fun popularNovelsParse(response: okhttp3.Response): Pair<List<SNovel>, Boolean> =
        parseNovelList(response, popularNovelsSelector())

    override fun latestNovelsParse(response: okhttp3.Response): Pair<List<SNovel>, Boolean> =
        parseNovelList(response, latestNovelsSelector())

    override fun searchNovelsParse(response: okhttp3.Response): Pair<List<SNovel>, Boolean> =
        parseNovelList(response, searchNovelsSelector())

    private fun parseNovelList(response: okhttp3.Response, selector: String): Pair<List<SNovel>, Boolean> {
        val document = response.asJsoup()
        val items = document.select(selector)
        val novels = items.mapNotNull { runCatching { novelFromElement(it) }.getOrNull() }
            .filter { it.title.isNotBlank() }
        val hasNext = document.selectFirst("a[rel=next], .pagination .next a, .pagination a.next") != null
        return novels to hasNext
    }

    private fun absoluteUrl(url: String): String {
        if (url.startsWith("http://") || url.startsWith("https://")) return url
        return if (url.startsWith("/")) "$baseUrl$url" else "$baseUrl/$url"
    }

    private fun absoluteImageUrl(url: String): String? {
        if (url.isBlank()) return null
        return absoluteUrl(url)
    }

    override fun headers() = super.headers().newBuilder()
        .add("Accept-Language", "ar,en;q=0.8")
        .build()
}
