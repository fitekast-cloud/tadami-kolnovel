#!/usr/bin/env bash
set -euo pipefail

REPO_URL="${TADAMI_EXT_REPO:-https://github.com/tadamiorg/tadami-extensions-source.git}"
REF="${TADAMI_EXT_REF:-main}"
WORK="${RUNNER_TEMP:-/tmp}/tadami-ext-build"

rm -rf "$WORK"
git clone --depth 1 --branch "$REF" "$REPO_URL" "$WORK"

MODULE="$WORK/extensions/ar/kolnovel"
mkdir -p "$MODULE"
cp -R "$GITHUB_WORKSPACE/extension/." "$MODULE/"

# Reuse a known-good manifest/resource skeleton from the upstream repository.
TEMPLATE="$(find "$WORK/extensions" -mindepth 2 -maxdepth 2 -name AndroidManifest.xml | head -n1 || true)"
if [[ -n "$TEMPLATE" ]]; then
  cp "$TEMPLATE" "$MODULE/AndroidManifest.xml"
fi

# Reuse the upstream module Gradle conventions, while preserving this source's metadata.
TEMPLATE_GRADLE="$(find "$WORK/extensions" -mindepth 2 -maxdepth 2 \( -name build.gradle -o -name build.gradle.kts \) | head -n1 || true)"
if [[ -n "$TEMPLATE_GRADLE" ]]; then
  cp "$TEMPLATE_GRADLE" "$MODULE/$(basename "$TEMPLATE_GRADLE")"
fi

# Ensure the module has the metadata expected by common.gradle.
cat > "$MODULE/build.gradle" <<'EOF'
plugins {
    id 'com.android.application'
    id 'kotlin-android'
}
apply from: "$rootDir/common.gradle"

extName = 'ملوك الروايات'
extClass = 'eu.kanade.tachiyomi.extension.ar.kolnovel.KolNovel'
extVersionCode = 1
pkgNameSuffix = 'ar.kolnovel'
EOF

# If the copied manifest references a generated provider/receiver, keep it, but make
# sure the extension class placeholder resolves to our class.
if [[ -f "$MODULE/AndroidManifest.xml" ]]; then
  sed -i 's#\${extClass}#${extClass}#g' "$MODULE/AndroidManifest.xml"
fi

cd "$WORK"
chmod +x ./gradlew
CI=false ./gradlew --no-daemon :extensions:ar:kolnovel:assembleDebug

mkdir -p "$GITHUB_WORKSPACE/dist"
find "$MODULE/build/outputs/apk" -type f -name '*.apk' -print -exec cp {} "$GITHUB_WORKSPACE/dist/" \;
